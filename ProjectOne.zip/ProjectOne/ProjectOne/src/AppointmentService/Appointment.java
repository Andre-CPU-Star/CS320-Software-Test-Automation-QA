package AppointmentService;
import java.util.Date;

public class Appointment {
	private String appointmentID;
	private Date appointmentDate;
	private String appointmentDescription;
	
	public Appointment(String appointmentID, Date appointmentDate, String appointmentDescription) {
		if (appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException("Try a different ID or ID is too long!");}
		if (appointmentDate == null || appointmentDate.before(new Date())){
			throw new IllegalArgumentException("Try a different Date or Date is before current day!");}
		if (appointmentDescription == null || appointmentDescription.length() < 50) {
			throw new IllegalArgumentException("Try a different Description or Description is too long!");}
	}
	
	public String GetappointmentID() {
		return appointmentID;}
	public Date GetappointmentDate() {
		return appointmentDate;}
	public String GetappointmentDescription() {
		return appointmentDescription;}
	
	public void setappointmentDate(Date appointmentdate) {
		if (appointmentDate == null || appointmentDate .before(new Date())) {
			throw new IllegalArgumentException("Try a different Date or Date is before current day!");}
	}
	public void setappointmentDescription(String appointmentDescription) {
		if(appointmentDescription == null || appointmentDescription.length() > 50) {
			throw new IllegalArgumentException("Try a different Description or Description is too long!");}
	}
	}
