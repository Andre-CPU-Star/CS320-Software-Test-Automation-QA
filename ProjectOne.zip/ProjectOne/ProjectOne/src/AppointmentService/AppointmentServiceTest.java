package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calender;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {
	Date CreateTrueDate() {
		Calender B = calender.getInstance();
		B.set(2023, 10, 1, 5, 11);
		Date date = B.getTime();
		return date;}
	Date CreatefalseDate(){
		Date date = new Date();
		date.setTime(1111111);
		return date;}
	
	@Test
	void testConstructor() {
		var AppointmentService = new AppointmentService();
		assertTrue(AppointmentService.GetappointmentList().isEmpty());
		assertEquals(AppointmentService.GetaapointmentCount(), 0);
		AppointmentService.AddAppointment(CreateTrueDate(), "Appointment Description");
		AppointmentService.PrintappointmentList();}
	
	@Test
	void testAddAppointmentMethodNullappointmentDate() {
		var AppointmentService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{ AppointmentService.AddAppointment(null, "Appointment Description");});}
	@Test
	void testAddAppointmentMethodNullappointmentDescription() {
		var AppointmentService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{ AppointmentService.AddAppointment(CreateTrueDate(), null);});}
	@Test
	void testAddAppointmentMethodFalseappointmentDate() {
		var AppointmentService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{ AppointmentService.AddAppointment(CreatefalseDate(), "Appointment Description");});}
	@Test
	void testAddAppointmentMethodBadappointmentDescription() {
		var AppointmentService = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{ AppointmentService.AddAppointment(CreateTrueDate(), "Appointment Description is to long and doesnt meet requirments!");});}
	@Test
	void testAddAppointmentMethodValidAppointment() {
		var AppointmentService = new AppointmentService();
		AppointmentService.AddAppointment(CreateTrueDate(),"Description fits requirments!");
		assertEquals(AppointmentService.GetaapointmentCount(), 1);
		assertTrue(!AppointmentService.GetappointmentList().isEmpty());
		AppointmentService.PrintappointmentList();}
	@Test
	void testRemoveEmptyAppointment() {
		var appointmentService = new AppointmentService();
		appointmentService.RemoveAppointment("1111111");}
	@Test
	void testRemoveIDifNull() {
		var Appointmentservice = new AppointmentService();
		AppointmentService.AddAppointment(CreateTrueDate(), "Remove");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{AppointmentService.RemoveAppointment(null);});}
	@Test
	void testRemoveIDifLong() {
		var Appointmentservice = new AppointmentService();
		AppointmentService.AddAppointment(CreateTrueDate(), "Remove");
		Assertions.assertThrows(IllegalArgumentException.class, () ->{AppointmentService.RemoveAppointment("11111111111");});}
	@Test
	void testRemoveAppointmentifNotinList() {
		var AppointmentService = new AppointmentService();
		AppointmentService.AddAppointment(CreateTrueDate(), "Remove");
		AppointmentService.RemoveAppointment("1111111");
		AppointmentService.RemoveAppointment(AppointmentService.GetappointmentList());
		assertTrue(!AppointmentService.GetappointmentList().isEmpty());}
	@Test
	void testRemoveAppointmentifNnList() {
		var AppointmentService = new AppointmentService();
		AppointmentService.AddAppointment(CreateTrueDate(), "Remove");
		Appointment appointment = AppointmentService.GetappointmentList().elementAt(0);
		AppointmentService.RemoveAppointment(AppointmentService.GetappointmentID());
		assertTrue(AppointmentService.GetappointmentList().isEmpty());}	
	
	}
	

