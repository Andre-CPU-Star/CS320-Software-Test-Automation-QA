package TaskService;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public class TaskService {
	private final List<Task> taskList = new ArrayList<>();
	
	private String UniqueTaskID() {
		return UUID.randomUUID().toString().substring(
				0,Math.min(toString().length(),10));}
	private Task searchTask(String ID) throws Exception{
		int index = 0;
		while(index < taskList.size()) {
			if (ID.equals(taskList.get(index).getTaskID())) {
				return taskList.get(index);}
			index++;}
		throw new Exception("This task doesnt excist!");}
	
	public void newTask() {
		Task task = new Task(UniqueTaskID());
		taskList.add(task);}
	public void newTask(String name) {
		Task task = new Task(UniqueTaskID(), name);
		taskList.add(task);}
	public void newTask(String name, String desciprion) {
		Task task = new Task(UniqueTaskID(), name, desciprion);
		taskList.add(task);}
	public void deleteTask (String ID) throws Exception{
		taskList.remove(searchTask(ID));}
	public void updatename (String ID, String name) throws Exception{
		searchTask(ID).setname(name);}
	public void updatedescription(String ID, String description)
	throws Exception{
		searchTask(ID).setdescription(description);}
	public List<Task> getTaskList(){return taskList;}
			}

