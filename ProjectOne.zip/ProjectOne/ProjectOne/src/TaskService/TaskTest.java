package TaskService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskTest {
	private String ID, name, description;
	private String ID2L, name2L, description2L;
	
	
	@BeforeEach
	void setUp() {
		ID = "1111111111";
		name = "twenty chars or less";
		description = "Insert  task  description  for  each  task pername";
		ID2L = "22222222222";
		name2L = "this is more than twenty chars";
		description2L = "Insert  task  description  for  each  task pername thats under 50 characters";}
	@Test
	void getTaskIDTest() {
		Task task = new Task(ID);
		Assertions.assertEquals(ID, task.getTaskID());}
	@Test
	void getNameTest() {
		Task task = new Task(ID, name);
		Assertions.assertEquals(name, task.getName());}
	@Test
	void getdescriptionTest() {
		Task task = new Task(ID, name, description);
		Assertions.assertEquals(description, task.getddescription());}
	@Test
	void setnameTest() {
		Task task = new Task();
		task.setname(name);
		Assertions.assertEquals(name, task.getName());}
	@Test
	void setdescriptionTest() {
		Task task = new Task();
		task.setdescription(description);
		Assertions.assertEquals(description, task.getddescription());}
	@Test
	void TaskID2L() {
		Assertions.assertThrows(IllegalArgumentException.class,() -> new Task(ID2L));}
	@Test
	void Taskname2L() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,() -> task.setname(name2L));}
	@Test
	void Taskdescription2L() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class,() -> task.setdescription(description2L));}
	@Test
	void TaskIDNULLTest() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> new Task(null));}
	@Test
	void TasknameNULLTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class, () -> task.setname(null));}
	@Test
	void TaskdescriptionNULLTest() {
		Task task = new Task();
		Assertions.assertThrows(IllegalArgumentException.class, () -> task.setdescription(null));}
	}
