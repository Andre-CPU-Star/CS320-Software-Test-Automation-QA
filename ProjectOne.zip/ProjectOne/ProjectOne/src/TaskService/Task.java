package TaskService;

public class Task {
	private String TaskID;
	private String name;
	private String description;
	
	Task(){
		TaskID = "Start";
		name = "Start";
		description = "Start";
	}
	Task(String TaskID){
		checkTaskID(TaskID);
		name = "Start";
		description = "Start description";}
	Task(String TaskID, String name){
		checkTaskID(TaskID);
		setname(name);
		description = "Start description";}
	Task(String TaskID, String name, String Description){
		checkTaskID(TaskID);
		setname(name);
		setdescription(description);}
	
	public final String getTaskID() {return TaskID;}
	public final String getName() {return name;}
	
	protected void setname(String name) {
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Name either doesnt excist ro is longer than 20 characters!");}
		else
			this.name = name;}
	
public final String getddescription() {return description;}

protected void setdescription(String taskdescription) {
	if (taskdescription.length() > 50) {
		throw new IllegalArgumentException("Description either doesnt excist or is longer than 50 characters");}
	else
		this.description = taskdescription;}
private void checkTaskID(String TaskID) {
	if(TaskID == null || TaskID.length() >10) {
		throw new IllegalArgumentException("Task ID either doesnt excist or is longer than 10 characters!");}
	else {
		this.TaskID = TaskID;
	}
}
}
