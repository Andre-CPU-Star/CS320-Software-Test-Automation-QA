package TaskService;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
		private String ID, name, description;
		private String ID2L, name2L, description2L;
		
	@BeforeEach
	void setUp() {
		ID = "1111111111";
		name = "twenty chars or less";
		description = "Insert  task  description  for  each  task pername";
		ID2L = "22222222222";
		name2L = "this is more than twenty chars";
		description2L = "Insert  task  description  for  each  task pername thats under 50 characters";}
	@Test
	void newTaskTest() {
		TaskService service = new TaskService();
		service.newTask();
		Assertions.assertNotNull(service.getTaskList().get(0).getTaskID());
		Assertions.assertNotEquals("START", service.getTaskList().get(0).getTaskID());}
	@Test
	void newTasknameTest() {
		TaskService service = new TaskService();
		service.newTask(name);
		Assertions.assertNotNull(service.getTaskList().get(0).getName());
		Assertions.assertNotEquals(name, service.getTaskList().get(0).getName());}
	@Test
	void newTaskdescriptionTest() {
		TaskService service = new TaskService();
		service.newTask(name, description);
		Assertions.assertNotNull(service.getTaskList().get(0).getddescription());
		Assertions.assertNotEquals(name, service.getTaskList().get(0).getddescription());}
	@Test
	void newTaskname2LTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalAgurmentException.class, () -> service.newTask(name2L));}
	@Test
	void newTaskdescription2LTest() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalAgurmentException.class, () -> service.newTask(name, description2L));}
	@Test
	void newTasknameNullTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalAgurmentException.class, () -> service.newTask(null));}
	@Test
	void newTaskdescriptionNullTest() {
		TaskService service = new TaskService();
		assertThrows(IllegalAgurmentException.class, () -> service.newTask(name, null));}
	@Test
	void deleteTaskTest() throws Exception {
		TaskService Service = new TaskService();
		Service.newTask();
		assertEquals(1, Service.getTaskList().size());
		Service.deleteTask(Service.getTaskList().get(0).getTaskID());
		assertEquals(1, Service.getTaskList().size());}
	@Test
	void deleteTaskNotfoundTest() throws Exception{
		TaskService Service = new TaskService();
		Service.newTask();
		assertEquals(1, Service.getTaskList().size());
		assertThrows(Exception.class, () -> Service.deleteTask(ID));
		assertEquals(1, Service.getTaskList().size());}
	@Test
	void updatenameTest() throws Exception{
		TaskService service = new TaskService();
		service.newTask();
		service.updatename(service.getTaskList().get(0).getTaskID(), name);
		assertEquals(name, service.getTaskList().get(0).getName());}
	@Test
	void updatedescriptionTest() throws Exception{
		TaskService service = new TaskService();
		service.newTask();
		service.updatedescription(service.getTaskList().get(0).getTaskID(), description);
		assertEquals(description, service.getTaskList().get(0).getddescription());}
	@Test
	void updatenameNotFoundList() throws Exception{
		TaskService service = new TaskService();
		service.newTask();
		assertThrows(Exception.class, () -> service.updatename(ID, name));}
	@Test
	void updatedescriptionNotFoundList() throws Exception{
		TaskService service = new TaskService();
		service.newTask();
		assertThrows(Exception.class, () -> service.updatedescription(ID, description));}
	
	}
