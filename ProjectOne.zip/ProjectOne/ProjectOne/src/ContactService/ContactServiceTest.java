package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	@Test
	void testNewcontact() throws Exception{
		ContactService service = new ContactService();
		service.newContact("1111", "John", "Dow", "1111111111", "1111 Test Drive");
		Contact contact = service.getContactList().get(0);
		assertEquals("1111", contact.getcontactID());
		assertEquals("John", contact.getfirstName());
		assertEquals("Dow", contact.getlastName());
		assertEquals("1111111111", contact.getphone());
		assertEquals("1111 Test Drive", contact.getaddress());
	}
	@Test
	void testdeleteTest() throws Exception{
		ContactService service = new ContactService();
			service.newContact("1111","John" , "Dow", "1111111111", "1111 Test Drive");
			service.newContact("2222","Josh", "Smith", "2222222222", "2222 Test Drive");
			service.newContact("3333","James", "Johnson", "3333333333", "3333 Test Drive");
				
				assertEquals(3, service.getContactList().size());
				service.deleteContact("1111");
				assertEquals(2, service.getContactList().size());
				service.deleteContact("2222");
				assertEquals(1, service.getContactList().size());
				service.deleteContact("3333");
				assertEquals(0, service.getContactList().size());
	}
	@Test
	void negativeTestforNewContact () throws Exception{
		ContactService service = new ContactService();
		service.newContact("1111", "John", "Dow", "1111111111", "1111 Test Drive");
			assertThrows(IllegalArgumentException.class, () -> service.newContact("1111", "John", "Dow", "1111111111", "1111 Test Drive"));
	}
	@Test
	void negativeTestforDeleteContact () throws Exception{
		ContactService service = new ContactService();
		service.newContact("1111", "John", "Dow", "1111111111", "1111 Test Drive");
		assertThrows(IllegalArgumentException.class,() -> service.deleteContact("4444"));
	}
}
