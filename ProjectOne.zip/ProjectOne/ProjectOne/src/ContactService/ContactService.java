package ContactService;

import java.util.ArrayList;
import java.util.List;

public class ContactService {
	public List<Contact> contactList = new ArrayList<Contact>();
	public void newContact(String contactID, String firstName, String lastName, String phone, String address) throws Exception{
		for (int i = 0; i < contactList.size();) {
			if (contactID.equals(contactList.get(i).getcontactID()));
			{
				throw new IllegalArgumentException("Contact exists!");
			}
		}
			contactList.add(new Contact(contactID, firstName, lastName, phone, address));
		}
		public void deleteContact(String id){
			for (int i = 0; i < contactList.size();) {
				if (id.equals(contactList.get(i).getcontactID())){
					contactList.remove(i);
					return;
				}
				throw new IllegalArgumentException("Contact doesnt Excist!");
			}
		}
		public List<Contact> getContactList()
		{
			return contactList;
		}
}
