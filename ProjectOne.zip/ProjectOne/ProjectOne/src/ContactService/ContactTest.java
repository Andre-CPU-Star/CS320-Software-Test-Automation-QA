package ContactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	@Test
	void testgetters() {
		Contact contact = new Contact("1111", "John", "Dow", "1111111111", "1111 Test Drive");
		assertEquals("1111", contact.getcontactID());
		assertEquals("John", contact.getfirstName());
		assertEquals("Dow", contact.getlastName());
		assertEquals("1111111111", contact.getphone());
		assertEquals("1111 Test Drive", contact.getaddress());
	}
	@Test
	void testsetters() {
		Contact contact = new Contact("2222", "John", "Smith", "2222222222", "2222 Test Drive");
			contact.updateContactID("2222");
			contact.updatefirstName("John");
			contact.updatelastName("Smith");
			contact.updatePhone("2222222222");
			contact.updateAddress("2222 Test Drive");
			assertEquals("2222", contact.getcontactID());
			assertEquals("John", contact.getfirstName());
			assertEquals("Smith", contact.getlastName());
			assertEquals("2222222222", contact.getphone());
			assertEquals("2222 Test Drive", contact.getaddress());
	}
	@Test
	void negativeTestforNull() {
		Contact contact = new Contact ("333","James", "Johnson", "3333333333", "3333 Test Drive");
		assertThrows(IllegalArgumentException.class, () -> contact.updateContactID(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updatefirstName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updatelastName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updatePhone(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updateAddress(null));
	}
	@Test
	void negativetestforinvalidcharacters(){
		Contact contact = new Contact("333","James", "Johnson", "3333333333", "3333 Test Drive");
		assertThrows(IllegalArgumentException.class, () -> contact.updateContactID(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updatefirstName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updatelastName(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updatePhone(null));
		assertThrows(IllegalArgumentException.class, () -> contact.updateAddress(null));
	}
	}
