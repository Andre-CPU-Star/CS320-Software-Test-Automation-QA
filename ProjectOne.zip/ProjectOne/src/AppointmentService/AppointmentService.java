package AppointmentService;

import java.util.Date;
import java.util.Random;
import java.util.Vector;

public class AppointmentService {
	private static Vector<Appointment> appointmentList = new Vector <Appointment>();
	private static int appointmentCount = 0;
	
	public Vector<Appointment> GetappointmentList(){
		return appointmentList;}
	public static int GetaapointmentCount() {
		return appointmentCount;}
	public void PrintappointmentList() {
		for (Appointment A : appointmentList) {
			System.out.println("Appointment ID:"+ A.GetappointmentID() + "Appointment Date: " + A.GetappointmentDate().toString() + "Appointment Description: " + A.GetappointmentDescription());}}
	
	public static void AddAppointment(Date appointmentDate, String appointmentDescription) {
		Date today = new Date();
		if (appointmentDate == null || appointmentDate.before(today)){
			throw new IllegalArgumentException("Try a different Date or Date is before current day!");}
		if (appointmentDescription == null ){
			throw new IllegalArgumentException("Try a different Description or Description is too long!");}
		
		String newappointmentID = GenerateUniqueID();
		var newAppointment = new Appointment(newappointmentID, appointmentDate, appointmentDescription);
		appointmentList.add(newAppointment);
		appointmentCount = GetaapointmentCount() + 1;}
	
	public void RemoveAppointment(String appointmentID) {
		if(appointmentList.isEmpty()) {
			System.out.print("That appointment doesnt excists!");}
		if ( appointmentID == null || appointmentID.length() > 10) {
			throw new IllegalArgumentException("That ID doesnt work!");}
		
		int index = -1;
		for(Appointment A : appointmentList){
				if (A.GetappointmentID() == appointmentID) {
					index = appointmentList.indexOf(A);}
				if (index == -1) {
					System.out.print("Appointment ID not aviable!");
					return;}
				else {
				appointmentList.remove(index);
				appointmentCount = GetaapointmentCount() -1;
				System.out.print("Appointment was removed!");}}}
				
	public static String GenerateUniqueID() {
		int Count = 0;
		Random random= new Random();
		int newID = random.nextInt(1111111111);
		String uniqueID = Integer.toString(newID);
		Vector<String> idList = new Vector<String>();
		for (Appointment A: appointmentList) {
			idList.add(A.GetappointmentDate());}
		
		while (idList.contains(uniqueID) || uniqueID.length() > 10) {
			newID = random.nextInt(1111111111);
			uniqueID = Integer.toString(newID);
			Count++;
			if (Count > 1111111111) {
				System.out.print("Your have exceeded number of ID");
				break;}
		}
		idList = null;
		return uniqueID;
	
			}
		}
