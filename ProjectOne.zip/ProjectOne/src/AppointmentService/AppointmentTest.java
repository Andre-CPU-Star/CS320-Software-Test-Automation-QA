package AppointmentService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

	@Test
	void testappointmentConstructor() {
		Calendar B = Calendar.getInstance();
		B.set(2023, 10, 1, 5, 11);
		Date date = B.getTime();
		System.out.print("The Date is: " + date);
		
	Assertions.assertThrows(IllegalArgumentException.class, () ->{new Appointment("1111111111", date, "appointment Description");});
	Assertions.assertThrows(IllegalArgumentException.class, () ->{new Appointment("1111111111", date, "Description is to long");});
	Assertions.assertThrows(IllegalArgumentException.class, () ->{new Appointment("1111111111", date, null);});
	Assertions.assertThrows(IllegalArgumentException.class, () ->{new Appointment("1111111111", date, "Appointment Description");});
	
	Date newDate = B.getTime();
	Appointment appointment = new Appointment("1111111111", newDate, "Appointment Description");
	assertTrue(appointment.GetappointmentID().equals("1111111111"));
	assertTrue(appointment.GetappointmentDate().equals(newDate));
	assertTrue(appointment.GetappointmentDescription().equals("Appointment description"));}
	
	@Test
	void testsetters() {
		Calendar B = Calendar.getInstance();
		B.set(2023, 10, 1, 5, 11);
		Date date = B.getTime();
		Date newDate = B.getTime();
		Date badDate = new Date();
		badDate.setTime(11111);
		
		Appointment appointment = new Appointment("1111111111", date, "appointment Description");
		appointment.setappointmentDescription("Description");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {appointment.setappointmentDescription("-------------------------Description too long!--------------------);");});
		assertTrue(appointment.GetappointmentDescription().equals("Description"));
		Assertions.assertThrows(IllegalArgumentException.class, () ->{appointment.setappointmentDate(badDate);
		Assertions.assertThrows(IllegalArgumentException.class, () ->{appointment.setappointmentDate(null);
		appointment.setappointmentDate(newDate);
		assertTrue(appointment.GetappointmentDate().equals(newDate));
		}
		}
	}
}
